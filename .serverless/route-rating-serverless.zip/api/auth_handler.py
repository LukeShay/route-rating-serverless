from api.utils.response_utils import ResponseUtils
from api.auth import Auth
from api.utils.logging_utils import setup_logger


def handler(event, context):
    setup_logger()

    return (
        ResponseUtils.ok_response()
        if Auth(event).validate_jwt()
        else ResponseUtils.forbidden_response()
    )

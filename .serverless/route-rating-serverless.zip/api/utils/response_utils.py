import json


class ResponseUtils:
    @staticmethod
    def ok_json_response(body):
        return ResponseUtils.ok_response(json.dumps(body))

    @staticmethod
    def ok_response(body=None):
        return ResponseUtils.response(body=body)

    @staticmethod
    def response(status_code=200, body=None):
        return {"statusCode": status_code, "body": body}

    @staticmethod
    def unauthorized_response(body=None):
        return ResponseUtils.response(status_code=401, body=body)

    @staticmethod
    def forbidden_response(body=None):
        return ResponseUtils.response(status_code=403, body=body)
